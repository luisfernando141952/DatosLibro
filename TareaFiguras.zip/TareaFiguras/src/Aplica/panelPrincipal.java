package Aplica;

import Clases.*;
import Dibujo.*;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JOptionPane;
/**
 *
 * @author Cabina10
 */
public class panelPrincipal extends javax.swing.JPanel {

    public panelPrincipal() {
        initComponents();
        valoresIniciales();
        
    }
    
    
    private void valoresIniciales(){     
        txtLado.setEnabled(false);
        txtRadio.setEnabled(false);
        txtBase.setEnabled(false);
        txtAltura.setEnabled(false);
        txtDma.setEnabled(false);
    }
    
    void botones(){
        btnCuadrado.setEnabled(true);
        btnCubo.setEnabled(true);
        btnCirculo.setEnabled(true);
        btnTriangulo.setEnabled(true);
        btnRectangulo.setEnabled(true);
        btnRombo.setEnabled(true);
    }
    
    void cuadradoCubo(){
        btnCirculo.setEnabled(false);
        btnTriangulo.setEnabled(false);
        btnRectangulo.setEnabled(false);
        btnRombo.setEnabled(false);
        txtLado.requestFocus();
    }
    
    void circulo(){
        btnCuadrado.setEnabled(false);
        btnCubo.setEnabled(false);
        btnTriangulo.setEnabled(false);
        btnRectangulo.setEnabled(false);
        btnRombo.setEnabled(false);
        txtRadio.requestFocus();
    }
    
    void triangulo(){
        btnCuadrado.setEnabled(false);
        btnCubo.setEnabled(false);
        btnCirculo.setEnabled(false);
        btnRectangulo.setEnabled(false);
        btnRombo.setEnabled(false);
        txtBase.requestFocus();
    }
    
    void rectangulo(){
        btnCuadrado.setEnabled(false);
        btnCubo.setEnabled(false);
        btnTriangulo.setEnabled(false);
        btnCirculo.setEnabled(false);
        btnRombo.setEnabled(false);
        txtBase.requestFocus();
    }
    
    void rombo(){
        btnCuadrado.setEnabled(false);
        btnCubo.setEnabled(false);
        btnTriangulo.setEnabled(false);
        btnCirculo.setEnabled(false);
        btnRectangulo.setEnabled(false);
        txtDma.requestFocus();
    }
    
    public int leeLado(){
        try {
            return Integer.parseInt(txtLado.getText().trim());
        } catch (Exception e) {
            return -1;
        }
    }
    
    public int leeRadio(){
        try {
            return Integer.parseInt(txtRadio.getText().trim());
        } catch (Exception e) {
            return -1;
        }
    }
    
    public int leeBase(){
        try {
            return Integer.parseInt(txtBase.getText().trim());
        } catch (Exception e) {
            return -1;
        }
    }
    
    public int leeAltura(){
        try {
            return Integer.parseInt(txtAltura.getText().trim());
        } catch (Exception e) {
            return -1;
        }
    }
    
    public int leeDm(){
        try {
            return Integer.parseInt(txtDma.getText().trim());
        } catch (Exception e) {
            return -1;
        }
    }
    
    public void lista(Figura f){
        imprime(f.info());
        if(f instanceof Cubo){
            imprime("Volumen\t: " + ((Cubo) f).volumen());
        }
        imprime("-----------------------------------");
    }
    
    public void imprime(String s){
        txtSalida.append(s + "\n");
    }
    
    public void mensaje(String s){
        JOptionPane.showMessageDialog(this, s);
    } 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelPrincipal = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        panelOperaciones = new javax.swing.JPanel();
        btnCuadrado = new javax.swing.JButton();
        btnCubo = new javax.swing.JButton();
        btnBorrar = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();
        btnCirculo = new javax.swing.JButton();
        btnTriangulo = new javax.swing.JButton();
        btnRectangulo = new javax.swing.JButton();
        btnRombo = new javax.swing.JButton();
        panelDatos = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txtLado = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtRadio = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtSalida = new javax.swing.JTextArea();
        txtBase = new javax.swing.JTextField();
        txtAltura = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtDma = new javax.swing.JTextField();
        panelDibujo = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();

        panelPrincipal.setBackground(new java.awt.Color(0, 255, 255));

        jLabel1.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        jLabel1.setText("Áreas y Perímetros");

        panelOperaciones.setBackground(new java.awt.Color(102, 255, 102));
        panelOperaciones.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "- Seleccione -", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION));

        btnCuadrado.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/square_20px.png"))); // NOI18N
        btnCuadrado.setText("   Cuadrado");
        btnCuadrado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCuadradoActionPerformed(evt);
            }
        });

        btnCubo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/orthogonal_view_20px.png"))); // NOI18N
        btnCubo.setText("            Cubo");
        btnCubo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCuboActionPerformed(evt);
            }
        });

        btnBorrar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/delete_20px.png"))); // NOI18N
        btnBorrar.setText("         Borrar");
        btnBorrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBorrarActionPerformed(evt);
            }
        });

        btnSalir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/exit_sign_20px.png"))); // NOI18N
        btnSalir.setText("            Salir");
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });

        btnCirculo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/circle_20px.png"))); // NOI18N
        btnCirculo.setText("        Círculo");
        btnCirculo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCirculoActionPerformed(evt);
            }
        });

        btnTriangulo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/triangle_20px.png"))); // NOI18N
        btnTriangulo.setText("    Triángulo");
        btnTriangulo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTrianguloActionPerformed(evt);
            }
        });

        btnRectangulo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/rectangle_20px.png"))); // NOI18N
        btnRectangulo.setText("Rectángulo");
        btnRectangulo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRectanguloActionPerformed(evt);
            }
        });

        btnRombo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/rhombus_20px.png"))); // NOI18N
        btnRombo.setText("       Rombo");
        btnRombo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRomboActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelOperacionesLayout = new javax.swing.GroupLayout(panelOperaciones);
        panelOperaciones.setLayout(panelOperacionesLayout);
        panelOperacionesLayout.setHorizontalGroup(
            panelOperacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelOperacionesLayout.createSequentialGroup()
                .addContainerGap(22, Short.MAX_VALUE)
                .addGroup(panelOperacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnRectangulo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnTriangulo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCirculo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCubo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCuadrado, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnRombo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnBorrar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnSalir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(23, 23, 23))
        );
        panelOperacionesLayout.setVerticalGroup(
            panelOperacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelOperacionesLayout.createSequentialGroup()
                .addComponent(btnCuadrado)
                .addGap(6, 6, 6)
                .addComponent(btnCubo)
                .addGap(6, 6, 6)
                .addComponent(btnCirculo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnTriangulo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnRectangulo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnRombo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnBorrar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnSalir)
                .addGap(0, 14, Short.MAX_VALUE))
        );

        panelDatos.setBackground(new java.awt.Color(102, 255, 102));

        jLabel2.setText("Ingrese Lado :");

        jLabel3.setText("Radio :");

        txtRadio.setToolTipText("");

        txtSalida.setColumns(20);
        txtSalida.setRows(5);
        jScrollPane1.setViewportView(txtSalida);

        jLabel4.setText("base:");

        jLabel5.setText("Altura:");

        jLabel6.setText("Diagonal:");

        javax.swing.GroupLayout panelDatosLayout = new javax.swing.GroupLayout(panelDatos);
        panelDatos.setLayout(panelDatosLayout);
        panelDatosLayout.setHorizontalGroup(
            panelDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelDatosLayout.createSequentialGroup()
                .addContainerGap(61, Short.MAX_VALUE)
                .addGroup(panelDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel2)
                    .addComponent(jLabel4)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtBase, javax.swing.GroupLayout.DEFAULT_SIZE, 63, Short.MAX_VALUE)
                    .addComponent(txtLado)
                    .addComponent(txtDma))
                .addGap(46, 46, 46)
                .addGroup(panelDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel3)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtAltura, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
                    .addComponent(txtRadio))
                .addGap(22, 22, 22))
            .addGroup(panelDatosLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 317, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panelDatosLayout.setVerticalGroup(
            panelDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelDatosLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtLado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(txtRadio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(panelDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtBase, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel4)
                        .addComponent(jLabel5))
                    .addComponent(txtAltura))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtDma, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addGap(32, 32, 32)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        panelDibujo.setBackground(new java.awt.Color(255, 204, 255));

        javax.swing.GroupLayout panelDibujoLayout = new javax.swing.GroupLayout(panelDibujo);
        panelDibujo.setLayout(panelDibujoLayout);
        panelDibujoLayout.setHorizontalGroup(
            panelDibujoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 380, Short.MAX_VALUE)
        );
        panelDibujoLayout.setVerticalGroup(
            panelDibujoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 285, Short.MAX_VALUE)
        );

        jLabel7.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        jLabel7.setText("DIBUJANDO");

        javax.swing.GroupLayout panelPrincipalLayout = new javax.swing.GroupLayout(panelPrincipal);
        panelPrincipal.setLayout(panelPrincipalLayout);
        panelPrincipalLayout.setHorizontalGroup(
            panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelPrincipalLayout.createSequentialGroup()
                .addGap(272, 272, 272)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(panelPrincipalLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panelOperaciones, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                .addComponent(panelDatos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelPrincipalLayout.createSequentialGroup()
                        .addComponent(panelDibujo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelPrincipalLayout.createSequentialGroup()
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(122, 122, 122))))
        );
        panelPrincipalLayout.setVerticalGroup(
            panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelPrincipalLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGroup(panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelPrincipalLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(panelDatos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelPrincipalLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(panelOperaciones, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(30, 30, 30))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelPrincipalLayout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, 34, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(panelDibujo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(35, 35, 35))))
        );

        panelDibujo.getAccessibleContext().setAccessibleParent(panelPrincipal);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelPrincipal, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelPrincipal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        panelPrincipal.getAccessibleContext().setAccessibleParent(panelPrincipal);
    }// </editor-fold>//GEN-END:initComponents

    private void btnRomboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRomboActionPerformed
        txtDma.setEnabled(true);
        if (leeDm()== -1) {
            mensaje("Ingrese dato");
            rombo();
        }else{
            Rombo c = new Rombo(leeDm());
            lista(c);
        }
        AreaDibujoRo ac= new AreaDibujoRo();
        ac.setSize(1000, 1000);
        ac.enviarLado(leeDm());
        panelDibujo.removeAll();
        panelDibujo.add(ac);
        panelDibujo.revalidate();
        panelDibujo.repaint();
    }//GEN-LAST:event_btnRomboActionPerformed

    private void btnRectanguloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRectanguloActionPerformed
        txtBase.setEnabled(true);
        txtAltura.setEnabled(true);
        if (leeBase()== -1 || leeAltura()==-1) {
            mensaje("Ingrese datos");
            rectangulo();
        }else{
            Rectangulo c = new Rectangulo(leeBase(), leeAltura());
            lista(c);
        }
        AreaDibujoRec ac= new AreaDibujoRec();
        ac.setSize(1000, 1000);
        ac.enviarLado(leeBase(), leeAltura());
        panelDibujo.removeAll();
        panelDibujo.add(ac);
        panelDibujo.revalidate();
        panelDibujo.repaint();
    }//GEN-LAST:event_btnRectanguloActionPerformed

    private void btnTrianguloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTrianguloActionPerformed
        txtBase.setEnabled(true);
        if (leeBase()== -1) {
            mensaje("Ingrese dato");
            triangulo();
        }else{
            Triangulo c = new Triangulo(leeBase());
            lista(c);
        }
        AreaDibujoTri ac= new AreaDibujoTri();
        ac.setSize(1000, 1000);
        ac.enviarLado(leeBase());
        panelDibujo.removeAll();
        panelDibujo.add(ac);
        panelDibujo.revalidate();
        panelDibujo.repaint();
    }//GEN-LAST:event_btnTrianguloActionPerformed

    private void btnCirculoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCirculoActionPerformed
        txtRadio.setEnabled(true);
        if (leeRadio()== -1) {
            mensaje("Ingrese el radio");
            circulo();
        }else{
            Circulo c = new Circulo(leeRadio());
            lista(c);
        }
        AreaDibujoCir ac= new AreaDibujoCir();
        ac.setSize(1000, 1000);
        ac.enviarradio(leeRadio());
        panelDibujo.removeAll();
        panelDibujo.add(ac);
        panelDibujo.revalidate();
        panelDibujo.repaint();
    }//GEN-LAST:event_btnCirculoActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        int r = JOptionPane.showOptionDialog(null, "Estas Seguro de Salir ...?",
                "Cálculos de áreas", JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE, null, new Object[]{"Si Salgo",
                    "No Salgo"}, "No Salgo");
        if (r == 0) {
            System.exit(0);
        }
    }//GEN-LAST:event_btnSalirActionPerformed

    private void btnBorrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBorrarActionPerformed
        txtSalida.setText("");
        txtLado.setText("");
        txtRadio.setText("");
        txtBase.setText("");
        txtAltura.setText("");
        txtDma.setText("");
        txtLado.requestFocus();
        valoresIniciales();
        botones();
       // AplicaPolimorfismo c = new AplicaPolimorfismo();
       // c.setSize(new Dimension(580, 400));
    }//GEN-LAST:event_btnBorrarActionPerformed

    private void btnCuboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCuboActionPerformed
        txtLado.setEnabled(true);
        if (leeLado() == -1) {
            mensaje("Ingrese el lado");
            cuadradoCubo();
        }else{
            Cubo c = new Cubo(leeLado());
            lista(c);
        }
        AreaDibujoCub ac= new AreaDibujoCub();
        ac.setSize(1000, 1000);
        ac.enviarLado(leeLado());
        panelDibujo.removeAll();
        panelDibujo.add(ac);
        panelDibujo.revalidate();
        panelDibujo.repaint();
    }//GEN-LAST:event_btnCuboActionPerformed

    private void btnCuadradoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCuadradoActionPerformed
        txtLado.setEnabled(true);
        if (leeLado() == -1) {
            mensaje("Ingrese el lado");
            cuadradoCubo();
        }else{
            Cuadrado c = new Cuadrado(leeLado());
            lista(c);
        }
        AreaDibujoC ac= new AreaDibujoC();
        ac.setSize(1000, 1000);
        ac.enviarLado(leeLado());
        panelDibujo.removeAll();
        panelDibujo.add(ac);
        panelDibujo.revalidate();
        panelDibujo.repaint();
    }//GEN-LAST:event_btnCuadradoActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBorrar;
    private javax.swing.JButton btnCirculo;
    private javax.swing.JButton btnCuadrado;
    private javax.swing.JButton btnCubo;
    private javax.swing.JButton btnRectangulo;
    private javax.swing.JButton btnRombo;
    private javax.swing.JButton btnSalir;
    private javax.swing.JButton btnTriangulo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel panelDatos;
    private javax.swing.JPanel panelDibujo;
    private javax.swing.JPanel panelOperaciones;
    private javax.swing.JPanel panelPrincipal;
    private javax.swing.JTextField txtAltura;
    private javax.swing.JTextField txtBase;
    private javax.swing.JTextField txtDma;
    private javax.swing.JTextField txtLado;
    private javax.swing.JTextField txtRadio;
    private javax.swing.JTextArea txtSalida;
    // End of variables declaration//GEN-END:variables
}
