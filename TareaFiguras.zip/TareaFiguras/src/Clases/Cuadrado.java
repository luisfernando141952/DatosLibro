package Clases;

import java.awt.Color;
import java.awt.Graphics;
/**
 * 
 * @author Cabina10
 */
public class Cuadrado extends Figura{

    public int lado;
    
    public Cuadrado(int lado) {
        super("Cuadrado");
        this.lado = lado;
    }
    
    public Cuadrado(String nombre, int lado){
        super(nombre);
        this.lado = lado;
    }

    public Cuadrado() {
    super("inicia dibujo");
    }
    
    public int getLado() {
        return lado;
    }

    public void setLado(int lado) {
        this.lado = lado;
    }
    
     @Override
    public double area() {
       return getLado() * getLado();
    }

    @Override
    public double perimetro() {
        return 4 * getLado();
    }

    public void dibujarCuadrado(Graphics e){
        e.setColor(Color.blue);
        e.drawRect(10, 10, lado, lado);
        e.fillRect(10, 10, lado, lado);
    }
}
