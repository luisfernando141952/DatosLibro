package Clases;

import java.awt.Color;
import java.awt.Graphics;
/**
 * 
 * @author Cabina10
 */
public class Circulo extends Figura {

    protected int radio;
    
    public Circulo (int radio){
        super("Circulo");
        this.radio = radio;
    }

    public Circulo() {
        super("Dibujando círculo");
    }

    public double getRadio() {
        return radio;
    }

    public void setRadio(int radio) {
        this.radio = radio;
    }
    
    @Override
    public double area() {
       return Math.PI * getRadio() * getRadio();
    }

    @Override
    public double perimetro() {
        return 2 * Math.PI * getRadio();
    }

    public void dibujarCirculo(Graphics g) {
        g.setColor(Color.blue);
        g.drawOval(10, 10, radio, radio);
        g.fillOval(10, 10, radio, radio);
    }
}
