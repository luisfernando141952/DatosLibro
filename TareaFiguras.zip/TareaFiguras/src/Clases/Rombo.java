package Clases;

import java.awt.Color;
import java.awt.Graphics;
/**
 * 
 * @author Cabina10
 */
public class Rombo extends Figura{

    protected int dm ;
    public Rombo(int dm) {
        super("Rombo");
        this.dm=dm;
        
    }

    public Rombo() {
        super("Dibujando Rombo");
    }

    public double getDm() {
        return dm;
    }

    public void setDm(int dm) {
        this.dm = dm;
    }
    @Override
    public double area() {
      return  (dm * dm) /2;
    }

    @Override
    public double perimetro() {
       return dm*4;
    }

    public void dibujarRombo(Graphics g) {
        g.setColor (Color.black);
        int [] x = {0+dm, dm*2, dm*3, dm*2};
        int [] y = {dm*2, 0+dm, dm*2, dm*3};
        g.drawPolygon (x, y, 4);
        g.fillPolygon (x, y, 4);
    }
}
