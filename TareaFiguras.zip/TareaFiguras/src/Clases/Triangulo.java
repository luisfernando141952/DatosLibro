package Clases;

import java.awt.Color;
import java.awt.Graphics;
/**
 * 
 * @author Cabina10
 */
public class Triangulo extends Figura{
    
    protected int base, altura;

    public Triangulo(int base ) {
        super("Triangulo");
        this.base=base;
        
        
    }

    public Triangulo() {
        super("Dibujando Triángulo");
    }

    public double getBase() {
        return base;
    }

    public void setBase(int base) {
        this.base = base;
    }

    public double getAltura() {
        return altura;
    }

    @Override
    public double area() {
        return (getBase() * getBase()) /2; 
    }

    @Override
    public double perimetro() {
        return  3 * getBase(); 
    } 

    public void dibujarTriangulo(Graphics g) {
         g.setColor (Color.black);
        int [] x = {base, base*2, base*3};
        int [] y = {base*3, base, base*3};
        g.drawPolygon (x, y, 3);
        g.fillPolygon (x, y, 3);
    }
}
