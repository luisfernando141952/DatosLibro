package Clases;

import java.awt.Color;
import java.awt.Graphics;
/**
 * 
 * @author Cabina10
 */
public class Cubo extends Cuadrado {

    public Cubo(int lado) {
        super("Cubo", lado);
    }

    public Cubo() {
    }
    
    public double area(){
        return super.area() * 6;
    }

    public double perimetro(){
        return super.perimetro() * 6;
    }
    
    public double volumen(){
        return Math.pow(getLado(), 3);
    }
    
    public void dibujarCubo(Graphics g)
    {
        int mitad=lado/2;
        int[] x={lado+0,lado+0,lado+lado,lado+lado};
        int[] y={lado+0,lado+lado,lado+lado,lado+0};
        g.setColor(Color.white);
        g.drawPolygon(x, y, 4);
        int[] i={lado+mitad,lado+mitad,lado+lado+mitad,lado+lado+mitad};
        int[] j={lado+mitad,lado+lado+mitad,lado+lado+mitad,lado+mitad};
        g.drawPolygon(i, j, 4);
        int[] z={lado+mitad,lado+0};
        int[] c={lado+lado+mitad,lado+lado};
        g.drawPolygon(z, c, 2);
        int[] a={lado+mitad,lado+0};
        int[] b={lado+mitad,lado+0};
        g.drawPolygon(a, b, 2);
        int[] d={lado+mitad+lado,lado+lado};
        int[] e={lado+mitad,lado+0};
        g.drawPolygon(d,e, 2);
        int[] f={lado+mitad+lado,lado+lado};
        int[] h={lado+mitad+lado,lado+lado};
        g.drawPolygon(f,h, 2);
    }
}
