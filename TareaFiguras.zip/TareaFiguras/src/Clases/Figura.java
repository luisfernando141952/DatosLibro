package Clases;
/**
 * 
 * @author Cabina10
 */
public abstract class Figura {

    protected String nombre;

    public Figura(String nombre) {
        this.nombre = nombre;
    }
    
    public abstract double area();
    public abstract double perimetro();
    
    public String info(){
        return "    === RESULTADO ===   \n"
                + " Figura \t : "+ nombre +"\n"
                + " Area \t : "+ area() +"\n"
                + " Perimetro \t : "+ perimetro()+"\n";
    }
}
