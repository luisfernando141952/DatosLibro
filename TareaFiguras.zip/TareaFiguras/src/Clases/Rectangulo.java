package Clases;

import java.awt.Color;
import java.awt.Graphics;
/**
 * 
 * @author Cabina10
 */
public class Rectangulo extends Figura{

    protected int base , altura;
    
    public Rectangulo(int base, int altura) {
        super("Rectángulo");
        this.base=base;
        this.altura=altura;
    }

    public Rectangulo() {
        super("Dibujando Rectangulo");
    }

    public double getBase() {
        return base;
    }

    public void setBase(int base) {
        this.base = base;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(int altura) {
        this.altura = altura;
    }
    
    @Override
    public double area() {
       return getBase() * getAltura();
    }

    @Override
    public double perimetro() {
        return (getBase() * 2) + (getAltura()*2);
    }
    
     public void dibujarRectangulo(Graphics e){
        
        e.setColor(Color.blue);
        e.drawRect(10, 10, base, altura);
        e.fillRect(10, 10, base, altura);
    }
}
