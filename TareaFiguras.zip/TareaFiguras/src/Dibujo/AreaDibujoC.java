package Dibujo;

import Clases.Cuadrado;
import java.awt.Graphics;


public class AreaDibujoC extends javax.swing.JPanel {
    
    Cuadrado objCuadrado = new Cuadrado();

    public AreaDibujoC() {
        initComponents();
        
    }
    
    public void enviarLado(int lado){
        objCuadrado.setLado(lado);
    }
    
    public void paint(Graphics g) {
        super.paint(g); 
        objCuadrado.dibujarCuadrado(g);
    }
    
    public void actualizar(){
        repaint();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setBackground(new java.awt.Color(0, 102, 102));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 415, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 404, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents
    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
