package Dibujo;

import Clases.Triangulo;
import java.awt.Graphics;

public class AreaDibujoTri extends javax.swing.JPanel {

    Triangulo objTriangulo = new Triangulo();
    
    public AreaDibujoTri() {
        initComponents();
    }
     public void enviarLado(int lado){
        objTriangulo.setBase(lado); 
    }
     
    public void paint(Graphics g) {
        super.paint(g); 
        objTriangulo.dibujarTriangulo(g);
    }
    
    public void Actualizar(){
        repaint();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setBackground(new java.awt.Color(0, 102, 102));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 488, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 529, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents
    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
