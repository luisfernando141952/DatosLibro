package Dibujo;

import Clases.Rectangulo;
import java.awt.Graphics;


public class AreaDibujoRec extends javax.swing.JPanel {
 
    Rectangulo objRectangulo = new Rectangulo();
    public AreaDibujoRec() {
        initComponents();   
    }
    
    public void enviarLado(int lado, int altura){
        objRectangulo.setBase(lado);
        objRectangulo.setAltura(altura);
    }
     
    public void paint(Graphics g) {
        super.paint(g); 
        objRectangulo.dibujarRectangulo(g);
    }
    
    public void Actualizar(){
        repaint();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setBackground(new java.awt.Color(0, 102, 102));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents
    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
